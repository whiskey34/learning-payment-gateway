        
        <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <p class="card-title">Supplier List</p>
                    <div class="pull-right">
                        <a href="<?= site_url('supplier/add');?>" class="btn btn-primary btn-flat mb-3">
                            <i class="ti-plus"></i>
                            Create
                        </a>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <div class="table-responsive">
                            
                          <table id="userTable" class="table table-hover" style="width:100%">
                            <thead>
                              <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Description</th>
                                <th>Actions</th>
                                <th></th>
                              </tr>
                            </thead>

                            <tbody>
                                <?php $no = 1; foreach($row->result() as $hasil => $data) { ?>
                                <tr>
                                    <td><?= $no ++; ?></td>
                                    <td><?= $data->name; ?></td>
                                    <td><?= $data->phone; ?></td>
                                    <td><?= $data->address; ?></td>
                                    <td><?= $data->description; ?></td>
                                    <td>
                                        
                                          <a href="<?= site_url('supplier/edit/'.$data->supplier_id);?>" class="btn btn-warning btn-xs">
                                              <i class="ti-pencil"></i>
                                              Edit
                                          </a> |
                                          <a href="<?= site_url('supplier/delete/'.$data->supplier_id);?>" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure ?')">
                                              <i class="ti-trash"></i>
                                              Delete
                                          </a> 
                                          
                                        
                                    </td>
                                    <td></td>
                                </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <?php $this->load->view('partials/_footer'); ?>
          
          <!-- partial -->


        </div>
        <!-- main-panel ends -->
     



